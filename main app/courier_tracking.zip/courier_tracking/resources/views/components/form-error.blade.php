 @props(['name'])
 @error($name)
     <p style="color: red; margin:5px 0 0 0; font-size:small;">{{ $message }}</p>
 @enderror

<?php if (isset($component)) { $__componentOriginalc25275877c450d488560b4c20559445e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc25275877c450d488560b4c20559445e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.adminLayout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('adminLayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="content">
        <section id="dashboard">
            <!-- <h3>Dashboard Overview</h3> -->
            <div class="grid-container">
                <div class="card">
                    <h3>Total Orders</h3>
                    <p><?php echo e($totalOrders); ?></p>
                </div>

                <div class="card">
                    <h3>Pending orders</h3>
                    <p><?php echo e($totalPending); ?></p>
                </div>
                <div class="card">
                    <h3>Delivered</h3>
                    <p><?php echo e($totalDelivered); ?></p>
                </div>
            </div>
        </section>
        <section id="orders">
            <h3>To be delivered Today</h3>
            <table>
                <thead>
                    <tr>
                        <th>Tracking Number</th>
                        <th>Product Name</th>
                        <th>Quantity</th>

                        <th>Destination</th>
                        <th>Customer Name</th>
                        <th>Customer Number</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($totalTodayOrders): ?>
                        <?php $__currentLoopData = $totalTodayOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a class="order-link"
                                        href="/admin/orders/<?php echo e($order['id']); ?>"><?php echo e($order['trackinNum']); ?></a>
                                </td>
                                <td>
                                    <a class="order-link"
                                        href="/admin/orders/<?php echo e($order['id']); ?>"><?php echo e($order['items']); ?></a>
                                </td>
                                <td>
                                    <a class="order-link"
                                        href="/admin/orders/<?php echo e($order['id']); ?>"><?php echo e($order['numItems']); ?></a>
                                </td>
                                <td>
                                    <a class="order-link"
                                        href="/admin/orders/<?php echo e($order['id']); ?>"><?php echo e($order['Destination']); ?>

                                    </a>
                                </td>
                                <td>
                                    <a class="order-link"
                                        href="/admin/orders/<?php echo e($order['id']); ?>"><?php echo e($order['customerName']); ?>

                                    </a>
                                </td>
                                <td>
                                    <a class="order-link"
                                        href="/admin/orders/<?php echo e($order['id']); ?>"><?php echo e($order['customerPhoneNum']); ?></a>
                                </td>
                                <td>
                                    <a href="/admin/orders/<?php echo e($order['id']); ?>/edite" class="btn btn-sm"
                                        href=""><i
                                            class="fa-solid action text-primary mx-3 fa-pen-to-square"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc25275877c450d488560b4c20559445e)): ?>
<?php $attributes = $__attributesOriginalc25275877c450d488560b4c20559445e; ?>
<?php unset($__attributesOriginalc25275877c450d488560b4c20559445e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc25275877c450d488560b4c20559445e)): ?>
<?php $component = $__componentOriginalc25275877c450d488560b4c20559445e; ?>
<?php unset($__componentOriginalc25275877c450d488560b4c20559445e); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Achu Promise\Documents\Web Dev Projects\Courier_tracking\main app\courier_tracking\resources\views/admin/dashboad.blade.php ENDPATH**/ ?>
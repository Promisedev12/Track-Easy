<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Header Start -->
    <div style="background: linear-gradient(rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.8)),
        url(<?php echo e(Vite::asset('resources/img/header.jpg')); ?>);"
        class="jumbotron jumbotron-fluid mb-5">
        <div class="container text-center py-5">
            <h1 class="text-white display-3">Service</h1>
            <div class="d-inline-flex align-items-center text-white">
                <p class="m-0"><a class="text-white" href="/">Home</a></p>
                <i class="fa fa-circle px-3"></i>
                <p class="m-0">Service</p>
            </div>
        </div>
    </div>
    <!-- Header End -->


    <!-- Services Start -->
    <?php if (isset($component)) { $__componentOriginal973531a6f9801fe04d3a0e840c62c25d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal973531a6f9801fe04d3a0e840c62c25d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.services','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('services'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal973531a6f9801fe04d3a0e840c62c25d)): ?>
<?php $attributes = $__attributesOriginal973531a6f9801fe04d3a0e840c62c25d; ?>
<?php unset($__attributesOriginal973531a6f9801fe04d3a0e840c62c25d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal973531a6f9801fe04d3a0e840c62c25d)): ?>
<?php $component = $__componentOriginal973531a6f9801fe04d3a0e840c62c25d; ?>
<?php unset($__componentOriginal973531a6f9801fe04d3a0e840c62c25d); ?>
<?php endif; ?>
    <!-- Services End -->
    <!--  Quote Request Start -->
    <?php if (isset($component)) { $__componentOriginalceaaca65260eb9e78a3c12d51ef41c80 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalceaaca65260eb9e78a3c12d51ef41c80 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.quoteReques','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('quoteReques'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalceaaca65260eb9e78a3c12d51ef41c80)): ?>
<?php $attributes = $__attributesOriginalceaaca65260eb9e78a3c12d51ef41c80; ?>
<?php unset($__attributesOriginalceaaca65260eb9e78a3c12d51ef41c80); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalceaaca65260eb9e78a3c12d51ef41c80)): ?>
<?php $component = $__componentOriginalceaaca65260eb9e78a3c12d51ef41c80; ?>
<?php unset($__componentOriginalceaaca65260eb9e78a3c12d51ef41c80); ?>
<?php endif; ?>
    <!-- Quote Request Start -->
    <!-- Testimonial Start -->
    <?php if (isset($component)) { $__componentOriginal609a9b4936b0d46ed1e2e59baae41e2b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal609a9b4936b0d46ed1e2e59baae41e2b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.testimonial','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('testimonial'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal609a9b4936b0d46ed1e2e59baae41e2b)): ?>
<?php $attributes = $__attributesOriginal609a9b4936b0d46ed1e2e59baae41e2b; ?>
<?php unset($__attributesOriginal609a9b4936b0d46ed1e2e59baae41e2b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal609a9b4936b0d46ed1e2e59baae41e2b)): ?>
<?php $component = $__componentOriginal609a9b4936b0d46ed1e2e59baae41e2b; ?>
<?php unset($__componentOriginal609a9b4936b0d46ed1e2e59baae41e2b); ?>
<?php endif; ?>
    <!-- Testimonial End -->

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Achu Promise\Documents\Web Dev Projects\Courier_tracking\main app\courier_tracking\resources\views/services.blade.php ENDPATH**/ ?>
    <!-- Header Start -->
    <div style="background: linear-gradient(rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.8)),
        url(<?php echo e(Vite::asset('resources/img/header.jpg')); ?>);"
        class="jumbotron jumbotron-fluid mb-5">
        <div class="container text-center py-5">

            <?php echo e($slot); ?>

        </div>
    </div>
    <!-- Header End -->
<?php /**PATH C:\Users\Achu Promise\Documents\Web Dev Projects\Courier_tracking\main app\courier_tracking\resources\views/components/header.blade.php ENDPATH**/ ?>